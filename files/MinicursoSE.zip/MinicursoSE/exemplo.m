% A = ones(3);
% B = zeros(3);
% 
% [linhas, colunas] = size(A);

%for linha=1:linhas
%    for coluna=[1 2 3]
%        B(linha, coluna) = A(linha, coluna);
%    end
%end
% 
% A(1,1) = 2;
% A(1,2) = 3;
% disp(A);
% 
% for indice=1:linhas
%     B(:, indice) = A(indice, :)';
% end
% 
% disp(B);

% for ii=1:10
%     if ii == 7
%         break;
%     elseif ii == 4
%         continue;
%     else
%        disp(ii); 
%     end
% end
% 

%try
    a = ['tres'; 'quatro'];
    a = 2;
    disp(a);
%catch
%    disp('Ocorreu um erro');
%end