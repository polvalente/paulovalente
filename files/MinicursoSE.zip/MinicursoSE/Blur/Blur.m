function [ out ] = Blur( img, nivel )
    L = 2*nivel+1;
    mask = ones(L)/(L*L);
        
    img = rgb2gray(img);
    [M,N] = size(img);
    out = zeros(M,N);
    img = [zeros(nivel, N); img; zeros(nivel, N)];
    img = [zeros(M+2*nivel, nivel) img zeros(M+2*nivel, nivel)];
    for row=(nivel+(1:M))
        for col=(nivel+(1:N))
            val = double(img(row-nivel:row+nivel,col-nivel:col+nivel)) .* mask;
            val = sum(val(:));
            out(row-nivel,col-nivel) = val;
        end
    end
    out = out./max(out(:));
end

