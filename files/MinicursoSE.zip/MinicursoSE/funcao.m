function [ output ] = funcao( m, n )
%FUNCAO funcao que multiplica o primeiro argumento pelo segundo
    output = m * n;
end

