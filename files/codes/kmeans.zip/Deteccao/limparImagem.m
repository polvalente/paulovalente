function [ COLOR, BW ] = limparImagem( filename, res, invert )
%LIMPARIMAGEM Recebe uma imagem e remove o ruido baseado em K-Means
    if nargin == 1
        res = 0.5;
        invert = 1;
    elseif nargin == 2
        invert = 1;
    elseif nargin == 3
    else
        fprintf('Numero invalido de argumentos\n');
        return
    end
    
    COLOR = imresize(imread(filename),res);
    COLOR = im2double(COLOR);
    A = im2double(rgb2gray(COLOR));
    A = A/max(A(:));
    if invert == 0
        A = 1 - A;
    end
    img_size = size(A);
    X = reshape(A, img_size(1) * img_size(2),1);
    %initial_centroids = kMeansInitCentroids(X, K);
    X = (X)/max(X(:));
    minX = min(X(:));
    maxX = max(X(:));
    meanX = mean(X(:));
    centroids = [minX; meanX; maxX];
    %initial_centroids =[minX; maxX];
    %[centroids] = runkMeans(X, initial_centroids, max_iters, false);
    K = 3;
    maxiter = 12;
    for iter = 1:maxiter
      % Passo de designacao do cluster. cluster(i) indica qual centroide foi selecionada para um dado ponto
      clusters = buscarCentroideProxima(X, centroids);

      %mover as centroids em direcao ao centro de seus respectivos clusters
      centroids = computarMedias(X, clusters, K);
    end
    
    idx = buscarCentroideProxima(X, centroids);
    X_recovered = centroids(idx,:);
    X_recovered = double(reshape(X_recovered, img_size(1), img_size(2),1) >= centroids(2));
    X_recovered = X_recovered - min(X_recovered(:));
    BW = ~(X_recovered/max(X_recovered(:)));
    B = zeros(size(COLOR,1),size(COLOR,2),size(COLOR,3));
    for index=1:size(COLOR,3)
        B(:,:,index) = BW;
    end
    if invert == 1
        C = ~B;
    else
        C = 0;
    end
    COLOR = COLOR .* double(B) + double(C);
end