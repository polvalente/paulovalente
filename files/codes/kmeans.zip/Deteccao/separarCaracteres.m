nome = './image1.jpg';
[color, clean] = limparImagem(nome,0.5);
imshow(color);

%utilizando a detec��o preto e branco para mascarar os caracteres na imagem
%colorida
T1 = 200;
clean = bwareaopen(clean,T1);
chars = bwconncomp(clean);
Z = zeros(chars.ImageSize);
%char_list = cell(chars.NumObjects);
bw_list = cell(chars.NumObjects);
%B = zeros(size(color,1),size(color,2),size(color,3));
for index=1:chars.NumObjects
    mask = Z;
    mask(chars.PixelIdxList{index}) = 1;
    %for index2=1:size(color,3)
    %    B(:,:,index2) = mask;
    %end
    %C = ~B;
    %char_list{index} = color .* double(B) + double(C);
    bw_list{index} = mask;
end

bounded_img_list = cell(chars.NumObjects);
for index=1:chars.NumObjects
    [~, min_x, max_x, min_y, max_y] = findBoundingBox(bw_list{index});
    %bounded_img_list{index} = char_list{index}(min_y:max_y,min_x:max_x,:);
    bounded_img_list{index} = color(min_y:max_y,min_x:max_x,:);
    figure;
    imshow(bounded_img_list{index});
end