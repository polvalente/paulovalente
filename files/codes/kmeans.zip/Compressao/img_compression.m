%% Carregando a imagem e convertendo para numero
  img = imread('ave_high.jpg');
  img = double(img)/255;

  %% Transformando a matriz de pixels em uma matriz de 3 colunas, onde cada linha � um pixel
  X = reshape(img, size(img,1) * size(img,2), 3);

  %% Configuracoes iniciais do K-Means
  K = 16;
  maxiter = 10;
  centroids = initializeCentroids(X, K);

  %% Execucao do algoritmo
  for iter = 1:maxiter
    fprintf('Executando a itera��o de n�mero: %d\n',iter);
    % Passo de designacao do cluster. cluster(iter) indica qual centroide foi selecionada para um dado ponto
    clusters = buscarCentroideProxima(X, centroids);

    %mover as centroids em direcao ao centro de seus respectivos clusters
    centroids = computarMedias(X, clusters, K);
  end

  idx = buscarCentroideProxima(X, centroids);
  X_recuperado = centroids(idx,:);
  img_comprimida = reshape(X_recuperado,size(img,1),size(img,2),3);

  %% Demonstracao do resultado

  figure;
  subplot(1,2,1);
  title('Original');
  imshow(img);
  subplot(1,2,2);
  title('Comprimida');
  imshow(img_comprimida);