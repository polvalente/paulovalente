% dados a serem processados estao no vetor X, e o algoritmo tem ordem K
centroids = initializeCentroids(X, K);

%maxiter e o numero maximo de iteracoes
maxiter = 20;
for iter = 1:maxiter
  % Passo de designacao do cluster. cluster(i) indica qual centroide foi selecionada para um dado ponto
  clusters = buscarCentroideProxima(X, centroids);

  %mover as centroids em direcao ao centro de seus respectivos clusters
  centroids = computarMedias(X, clusters, K);
end