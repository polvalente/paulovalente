function [centroids] = initializeCentroids(train_set, K)
  % [centroids] = initializeCentroids(train_set, K)
  % Essa funcao recebe um set de treino e a ordem K do algoritmo e retorna
  % as centroides iniciais para a execucao do algoritmo
  indices = randperm(size(train_set,1));
  centroids = train_set(indices(1:K), :);
end