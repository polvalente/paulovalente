function centroids = computarMedias(X, clusters, K)
  [~, n] = size(X);
  centroids = zeros(K, n);
  for m=1:K
    %selecionando os elementos pertencentes ao m-esimo cluster
    clusterK = X(clusters==m,:);
    %substituindo a centroide pelo "centro de massa" do cluster
    centroids(m,:) = mean(clusterK);
  end
end