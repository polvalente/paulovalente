function clusters = buscarCentroideProxima(X, centroids)

    K = size(centroids, 1);

    %prealocando espaco
    C = zeros(size(X,1), K);
    for index=1:K
    % calcula para cada ponto, sua distancia quadratica em relacao a cada uma das centroides

    % As linhas abaixo podem ser condensadas em uma so, para evitar chamadas desnecessarias de atribuicao de valores.

        distancia = bsxfun(@minus,X,centroids(index,:));
        distancia = distancia.^2;
        C(:,index) = sum( distancia, 2);
    end
    % binariza a matriz C, colocando 1 apenas aonde ha a minima distancia
    % quadratica, o que corresponde a melhor centroide para aquele ponto
    % Depois, a multiplicacao pelo vetor 1:K substitui cada linha da matriz pelo
    % indice da centroide correspondente

    clusters = bsxfun(@eq,C,min(C,[],2))*(1:K)';
end